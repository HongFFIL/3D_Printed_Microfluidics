#include <Arduino.h>

int pumpPin1 = 13;  // Forward pin
int pumpPin2 = 18;  // Backward pin
int power = 0;      // Default power level (0-255)

void setup() {
  pinMode(pumpPin1, OUTPUT);
  pinMode(pumpPin2, OUTPUT);
  // Start with motors off
  digitalWrite(pumpPin1, LOW);
  digitalWrite(pumpPin2, LOW);
  // Initialize serial communication
  Serial.begin(115200); // Ensure the baud rate matches your serial communication setup
}

void loop() {
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n'); // Read the incoming command
    if (command.startsWith("p")) {  // Set power level
      int newPower = command.substring(1).toInt();
      if (newPower >= 0 && newPower <= 255) {
        power = newPower;
        Serial.println("Power set to: " + String(power));
      } else {
        Serial.println("Invalid power level.");
      }
    } else if (command == "f") {  // Forward
      analogWrite(pumpPin1, power);
      analogWrite(pumpPin2, LOW);
    } else if (command == "b") {  // Backward
      analogWrite(pumpPin1, LOW);
      analogWrite(pumpPin2, power);
    } else if (command == "s") {  // Stop
      analogWrite(pumpPin1, LOW);
      analogWrite(pumpPin2, LOW);
    } else {
      Serial.println("Unknown command.");
    }
  }
}